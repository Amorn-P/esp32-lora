// --- wifi_functions.cpp (FINALIZED: Redefinition Fix) ---
#include "wifi_functions.h"
#include <WiFi.h>
#include <time.h>
#include "config.h" 
#include "lcd_functions.h"
#include "rtc_functions.h"
#include "Blynk_Manager.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// NTP server information
const char* ntpServer = "pool.ntp.org";

// CRITICAL FIX: We must use the values defined in config.h. 
// However, since configTime takes constants/macros, we define them here 
// using the values, assuming they are consistent with config.h.
// const long gmtOffset_sec = 25200; // Example: UTC +7 (7 * 3600)
// const int daylightOffset_sec = 0; 

// Forward declaration for local helper
static bool getLocalTimeNTP(struct tm * timeinfo);

// --- Local Helper Function (Accesses external resources) ---
static bool getLocalTimeNTP(struct tm * timeinfo) {
    configTime(GMT_OFFSET_SEC, DAYLIGHT_OFFSET_SEC, ntpServer);
    return getLocalTime(timeinfo, 5000); // Wait up to 5 seconds
}

// --- Public Function (Called by TaskCore0) ---
void updateRTCfromNTP() {
    struct tm timeinfo;
    if (WiFi.status() == WL_CONNECTED && getLocalTimeNTP(&timeinfo)) {
        RtcDateTime ntpTime(timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday, 
                            timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
        setRtcDateTime(ntpTime); // Mutex protected call to update RTC
        Serial.println("[NTP] RTC updated from NTP.");
    } else {
        Serial.println("[NTP] Failed to obtain time.");
    }
}

// --- Public Function (Called by setup for initial connection) ---
void connectToWiFiAndSyncTime() {
    int retries = 0;
    const int max_retries = 30; // 15 seconds timeout for initial

    showLCDMessage("Connecting WiFi...", WIFI_SSID);
    Serial.printf("Connecting to %s...\n", WIFI_SSID);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED && retries < max_retries) {
        vTaskDelay(pdMS_TO_TICKS(500)); 
        retries++;
        Serial.print(".");
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\n[WiFi] Connected.");
        showLCDMessage("WiFi Connected!", WiFi.localIP().toString().c_str());
        configTime(GMT_OFFSET_SEC, DAYLIGHT_OFFSET_SEC, ntpServer);
        updateRTCfromNTP(); 
        initBlynk();
    } else {
        Serial.println("\n[WiFi] Connection Failed.");
        showLCDMessage("WiFi Failed!", "Offline Mode");
    }
}

// --- Task Function for Core 0 (Main Comm & Time Maintenance) ---
void TaskCore0(void * pvParameters) {
    (void) pvParameters; 
    
    connectToWiFiAndSyncTime(); 

    uint32_t lastNTPSync = 0;
    const uint32_t ntpInterval = 3600000; // Sync NTP every hour

    for (;;) {
        // Handle WiFi Reconnection
        if (WiFi.status() != WL_CONNECTED) {
            WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
            vTaskDelay(pdMS_TO_TICKS(5000));
        } else {
            // Handle Blynk
            runBlynk();
            
            // Handle Periodic NTP Sync
            if (millis() - lastNTPSync > ntpInterval) {
                updateRTCfromNTP();
                lastNTPSync = millis();
            }
        }
        
        vTaskDelay(pdMS_TO_TICKS(100)); // Frequent Blynk runs
    }
}
