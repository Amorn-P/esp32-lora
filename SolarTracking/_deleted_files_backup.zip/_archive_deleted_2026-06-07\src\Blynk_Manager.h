#ifndef BLYNK_MANAGER_H
#define BLYNK_MANAGER_H

#include "User_config.h"

void initBlynk();
void runBlynk();
bool isBlynkConnected();
void blynkVirtualWrite(int pin, int value);
void blynkVirtualWrite(int pin, float value);
void blynkVirtualWrite(int pin, const char* value);

// Virtual Pin Mappings
#define V_PAN_POS    1
#define V_TILT_POS   2
#define V_LDR_LEFT   3
#define V_LDR_RIGHT  4
#define V_LDR_UP     5
#define V_LDR_DOWN   6
#define V_STATUS     7
#define V_MODE       8 // 0: Auto, 1: Manual

#endif
