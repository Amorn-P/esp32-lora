#include "Blynk_Manager.h"
#define BLYNK_PRINT Serial
#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = WIFI_SSID;
char pass[] = WIFI_PASSWORD;

void initBlynk() {
    Serial.println("Initializing Blynk...");
    Blynk.config(auth, BLYNK_SERVER, BLYNK_PORT);
    Blynk.connect();
}

void runBlynk() {
    if (Blynk.connected()) {
        Blynk.run();
    }
}

bool isBlynkConnected() {
    return Blynk.connected();
}

void blynkVirtualWrite(int pin, int value) {
    if (Blynk.connected()) {
        Blynk.virtualWrite(pin, value);
    }
}

void blynkVirtualWrite(int pin, float value) {
    if (Blynk.connected()) {
        Blynk.virtualWrite(pin, value);
    }
}

void blynkVirtualWrite(int pin, const char* value) {
    if (Blynk.connected()) {
        Blynk.virtualWrite(pin, value);
    }
}
