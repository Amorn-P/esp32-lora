# Final Wiring Checklist (Compiled C++ Truth)

| Component/Pin | ESP32 GPIO / Pin | Protocol / Usage |
|---------------|------------------|------------------|
| **I2C SDA**   | `GPIO 21`        | LCD, MPU6050, DS3231 (RTC), QMC5883L |
| **I2C SCL**   | `GPIO 22`        | LCD, MPU6050, DS3231 (RTC), QMC5883L |
| **Tilt UP**   | `GPIO 27`        | BTS7960 PWM (Motor 1) |
| **Tilt DOWN** | `GPIO 14`        | BTS7960 PWM (Motor 1) |
| **Pan CW**    | `GPIO 25`        | BTS7960 PWM (Motor 2) |
| **Pan CCW**   | `GPIO 26`        | BTS7960 PWM (Motor 2) |
| **Wind RX**   | `GPIO 16`        | RS485 MAX485 Module |
| **Wind TX**   | `GPIO 17`        | RS485 MAX485 Module |
| **Wind DE/RE**| `GPIO 4`         | RS485 Direction Control |