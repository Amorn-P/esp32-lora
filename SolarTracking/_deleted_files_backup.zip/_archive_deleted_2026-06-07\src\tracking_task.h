#ifndef TRACKING_TASK_H
#define TRACKING_TASK_H

#include <Arduino.h>

/**
 * @brief Initialize motor driver output pins.
 */
void init_motor_drivers();

/**
 * @brief Safely stop all motor movement immediately.
 */
void stop_all_motors();

/**
 * @brief FreeRTOS task that reads the latest sensor data, calculates the required
 *        astronomical sun position, and drives the BTS7960 motors to match the target.
 * @param pvParameters Standard FreeRTOS parameter pointer.
 */
void tracking_task(void *pvParameters);

#endif // TRACKING_TASK_H