# Zoo Code Engineering Directive: ESP32 Solar Tracker

**Role:** You are "Zoo Code", the autonomous C++ developer for this project. 
**Architect:** Lucky has already designed the FreeRTOS architecture and pipeline. 
**Hardware Lead:** DAD will handle physical wiring and deployment.

Your job is strictly to implement the logic within the pre-defined `.cpp` task loops. 

## 🛑 STRICT RULES OF ENGAGEMENT
1. **DO NOT modify `main.cpp`** beyond initializing the I2C (`Wire.begin()`) and Serial interfaces. The FreeRTOS task spawning is already locked.
2. **DO NOT change the task rates** (e.g., `vTaskDelayUntil`). They are engineered for specific I2C/RS485 bandwidths.
3. **USE THE MUTEX:** All tasks MUST use `xSemaphoreTake(stateMutex, portMAX_DELAY)` before reading or writing to the global `sysState` struct, and `xSemaphoreGive(stateMutex)` immediately after.
4. **NO SPAGHETTI:** Keep all hardware-specific code (e.g., MPU6050 reading) entirely contained within its respective task file.

## Task Implementation Requirements:

### 1. `sensor_task.cpp` (The Reality)
*   Include the Adafruit MPU6050 library.
*   Include the QMC5883L logic (you may need to write a simple I2C reader if a clean library isn't in `lib_deps`).
*   Read Pitch (Elevation) and Heading (Azimuth).
*   Apply a simple rolling average array (size 10) to smooth motor vibration noise.
*   Update `sysState.current_elevation` and `sysState.current_azimuth` under mutex lock.

### 2. `astro_task.cpp` (The Target)
*   Include `RTClib.h` for the DS3231.
*   **CRITICAL HARDWARE RULE:** You MUST use the `RTC_DS3231` object. Do NOT write code for DS1302 or DS1307. The DS3231 uses the I2C bus.
*   Write or include a Solar Position algorithm (calculating Azimuth/Elevation from Julian Day, Lat, Lon, Time). 
*   Update `sysState.target_elevation` and `sysState.target_azimuth` under mutex lock.

### 3. `safety_task.cpp` (Wind Monitor)
*   Include `ModbusMaster.h`.
*   Initialize `Serial2` for RS485 communication (Pins 16 RX, 17 TX, Pin 4 DE/RE).
*   Poll the wind speed register.
*   If the Modbus request returns `ku8MBSuccess`:
    *   Update `sysState.wind_speed_kph`.
    *   Set `sysState.wind_sensor_fault = false`.
    *   If speed > `STOW_WIND_SPEED_KPH`, set `sysState.wind_alarm = true`, else `false`.
*   If the request times out (unplugged):
    *   Set `sysState.wind_sensor_fault = true`.
    *   Set `sysState.wind_alarm = false` (allow normal tracking if fault-tolerant).

### 4. `motor_task.cpp` (The Control Loop)
*   Configure Pins 25, 26, 27, 14 using `ledcSetup()`, `ledcAttachPin()`.
*   Logic priority:
    1. If `sysState.wind_alarm == true`, drive Tilt motor until `current_elevation <= 2.0` (Stow flat). Stop Pan motor.
    2. Else, compare Targets vs Currents.
    3. If `abs(target - current) > DEAD_BAND_DEGREES`, drive motors using `ledcWrite()` to ramp up PWM smoothly.

### 5. `ui_task.cpp` (LCD Display)
*   Include `LiquidCrystal_I2C.h`.
*   Format the screen to show: Target (Az/El), Current (Az/El), Wind Speed, and System Mode (Tracking/Stow/Fault).

Execute the implementation now.