// --- wifi_functions.h --- 
#ifndef WIFI_FUNCTIONS_H 
#define WIFI_FUNCTIONS_H 
#include <Arduino.h> 
#include "freertos/task.h" 

void connectToWiFiAndSyncTime(); 
void updateRTCfromNTP(); 
void TaskCore0(void * pvParameters); 
#endif